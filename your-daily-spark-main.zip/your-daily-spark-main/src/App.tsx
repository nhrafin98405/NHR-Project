import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "@/hooks/useAuth";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import AppLayout from "@/components/AppLayout";
import Landing from "./pages/Landing";
import AuthPage from "./pages/Auth";
import Dashboard from "./pages/Dashboard";
import SendParcel from "./pages/SendParcel";
import MyParcels from "./pages/MyParcels";
import ParcelDetail from "./pages/ParcelDetail";
import HubOperations from "./pages/HubOperations";
import AdminHubs from "./pages/AdminHubs";
import AdminUsers from "./pages/AdminUsers";
import Notifications from "./pages/Notifications";
import NotFound from "./pages/NotFound.tsx";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <AuthProvider>
          <Routes>
            <Route path="/" element={<Landing />} />
            <Route path="/auth" element={<AuthPage />} />
            <Route path="/app" element={<ProtectedRoute><AppLayout /></ProtectedRoute>}>
              <Route index element={<Dashboard />} />
              <Route path="send" element={<ProtectedRoute roles={["customer", "admin"]}><SendParcel /></ProtectedRoute>} />
              <Route path="my-parcels" element={<ProtectedRoute roles={["customer", "admin"]}><MyParcels /></ProtectedRoute>} />
              <Route path="parcel/:id" element={<ParcelDetail />} />
              <Route path="hub" element={<ProtectedRoute roles={["hub_staff", "admin"]}><HubOperations /></ProtectedRoute>} />
              <Route path="hubs" element={<ProtectedRoute roles={["admin"]}><AdminHubs /></ProtectedRoute>} />
              <Route path="users" element={<ProtectedRoute roles={["admin"]}><AdminUsers /></ProtectedRoute>} />
              <Route path="notifications" element={<Notifications />} />
            </Route>
            <Route path="*" element={<NotFound />} />
          </Routes>
        </AuthProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
