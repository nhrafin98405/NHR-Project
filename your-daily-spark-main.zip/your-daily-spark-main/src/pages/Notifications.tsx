import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Bell } from "lucide-react";

export default function Notifications() {
  const { user } = useAuth();
  const [items, setItems] = useState<any[]>([]);

  const load = async () => {
    const { data } = await supabase
      .from("notifications")
      .select("*")
      .eq("user_id", user!.id)
      .order("created_at", { ascending: false });
    setItems(data || []);
    await supabase.from("notifications").update({ read: true }).eq("user_id", user!.id).eq("read", false);
  };

  useEffect(() => { if (user) load(); }, [user]);

  return (
    <Card>
      <CardHeader><CardTitle><Bell className="inline h-5 w-5 mr-1" /> Notifications</CardTitle></CardHeader>
      <CardContent className="space-y-2">
        {items.length === 0 && <p className="text-muted-foreground text-sm">No notifications yet.</p>}
        {items.map((n) => (
          <Link
            key={n.id}
            to={n.parcel_id ? `/app/parcel/${n.parcel_id}` : "#"}
            className="block border rounded-md p-3 hover:bg-accent"
          >
            <div className="font-medium text-sm">{n.title}</div>
            <div className="text-sm text-muted-foreground">{n.message}</div>
            <div className="text-xs text-muted-foreground mt-1">{new Date(n.created_at).toLocaleString()}</div>
          </Link>
        ))}
      </CardContent>
    </Card>
  );
}
