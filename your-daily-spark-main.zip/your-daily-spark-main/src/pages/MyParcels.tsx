import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Package } from "lucide-react";

interface Parcel {
  id: string;
  tracking_code: string;
  receiver_name: string;
  status: string;
  payment_status: string;
  amount: number;
  created_at: string;
}

const statusColor: Record<string, string> = {
  pending_pickup: "bg-orange-500",
  at_origin_hub: "bg-blue-500",
  in_transit: "bg-blue-600",
  at_destination_hub: "bg-purple-500",
  out_for_delivery: "bg-yellow-500",
  delivered: "bg-green-600",
  cancelled: "bg-gray-500",
};

export default function MyParcels() {
  const { user } = useAuth();
  const [parcels, setParcels] = useState<Parcel[]>([]);

  useEffect(() => {
    if (!user) return;
    supabase
      .from("parcels")
      .select("id,tracking_code,receiver_name,status,payment_status,amount,created_at")
      .eq("sender_id", user.id)
      .order("created_at", { ascending: false })
      .then(({ data }) => data && setParcels(data));
  }, [user]);

  return (
    <Card className="border-border/50 animate-fade-in">
      <CardHeader><CardTitle>My Parcels</CardTitle></CardHeader>
      <CardContent>
        {parcels.length === 0 ? (
          <div className="py-12 text-center">
            <div className="mx-auto h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center mb-3 animate-float">
              <Package className="h-8 w-8 text-primary" />
            </div>
            <p className="text-muted-foreground text-sm">No parcels yet. <Link to="/app/send" className="text-primary underline font-medium">Send one</Link>.</p>
          </div>
        ) : (
          <div className="space-y-2">
            {parcels.map((p, i) => (
              <Link
                key={p.id}
                to={`/app/parcel/${p.id}`}
                className="flex items-center gap-3 p-3 border border-border/50 rounded-lg hover:bg-accent hover:border-primary/30 hover:shadow-md transition-all group"
                style={{ animation: `slide-in-right 0.4s ease-out ${i * 0.05}s both` }}
              >
                <div className="h-11 w-11 rounded-lg bg-primary/10 flex items-center justify-center group-hover:bg-primary/20 group-hover:scale-110 transition-all">
                  <Package className="h-5 w-5 text-primary" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="font-semibold text-sm">{p.tracking_code}</div>
                  <div className="text-xs text-muted-foreground truncate">To: {p.receiver_name} • ৳{p.amount}</div>
                </div>
                <div className="flex flex-col items-end gap-1">
                  <Badge className={`${statusColor[p.status]} text-white border-0 text-xs`}>
                    {p.status.replace(/_/g, " ")}
                  </Badge>
                  <Badge variant={p.payment_status === "paid" ? "default" : "outline"} className="text-xs">
                    {p.payment_status}
                  </Badge>
                </div>
              </Link>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
