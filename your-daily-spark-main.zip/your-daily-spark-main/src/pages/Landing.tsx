import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Package, Truck, MapPin, Bell, Shield, Clock, ArrowRight, CheckCircle2, Zap } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";

export default function Landing() {
  const { user } = useAuth();
  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border/40 glass sticky top-0 z-40">
        <div className="container flex h-16 items-center justify-between">
          <Link to="/" className="flex items-center gap-2 group">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-hero text-primary-foreground transition-transform group-hover:scale-110 group-hover:rotate-3">
              <Package className="h-5 w-5" />
            </div>
            <span className="font-bold text-lg tracking-tight">CourierBD</span>
          </Link>
          <div className="flex items-center gap-2">
            <Link to={user ? "/app" : "/auth"}>
              <Button className="hover-scale">{user ? "Open App" : "Login / Sign up"}</Button>
            </Link>
          </div>
        </div>
      </header>

      <section className="relative overflow-hidden bg-gradient-mesh">
        <div className="container py-20 md:py-28 grid md:grid-cols-2 gap-10 items-center">
          <div className="animate-fade-in">
            <div className="inline-flex items-center gap-2 rounded-full border border-primary/20 bg-primary/5 px-3 py-1 text-xs font-medium text-primary mb-5">
              <Zap className="h-3 w-3" /> Trusted by 10,000+ shippers in Bangladesh
            </div>
            <h1 className="text-4xl md:text-6xl font-bold tracking-tight leading-[1.05]">
              Fast, reliable parcel delivery across{" "}
              <span className="text-gradient">Bangladesh</span>
            </h1>
            <p className="mt-5 text-lg text-muted-foreground max-w-xl">
              Book a parcel, track every hub-to-hub movement, and get notified when it arrives. Pay on send or on receive — your choice.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link to={user ? "/app/send" : "/auth"}>
                <Button size="lg" className="group bg-gradient-hero hover-scale shadow-lg shadow-primary/30">
                  Send a parcel
                  <ArrowRight className="ml-1 h-4 w-4 transition-transform group-hover:translate-x-1" />
                </Button>
              </Link>
              <Link to={user ? "/app/my-parcels" : "/auth"}>
                <Button size="lg" variant="outline" className="hover-scale">Track parcel</Button>
              </Link>
            </div>
            <div className="mt-8 flex flex-wrap gap-5 text-sm text-muted-foreground">
              {["Real-time tracking", "Cash on delivery", "64+ districts"].map((t) => (
                <div key={t} className="flex items-center gap-1.5">
                  <CheckCircle2 className="h-4 w-4 text-primary" /> {t}
                </div>
              ))}
            </div>
          </div>
          <div className="relative animate-scale-in">
            <div className="absolute -inset-4 bg-gradient-hero opacity-20 blur-3xl rounded-full" />
            <div className="relative aspect-square rounded-3xl bg-gradient-to-br from-primary/15 via-background to-[hsl(var(--accent-orange)/0.15)] p-8 flex items-center justify-center border border-border/50 shadow-2xl">
              <div className="grid grid-cols-2 gap-4 w-full max-w-md">
                {[
                  { icon: Truck, label: "Hub network", color: "text-primary" },
                  { icon: MapPin, label: "Live tracking", color: "text-[hsl(var(--accent-orange))]" },
                  { icon: Bell, label: "Notifications", color: "text-primary" },
                  { icon: Shield, label: "Secure", color: "text-[hsl(var(--accent-orange))]" },
                ].map((f, i) => (
                  <Card
                    key={f.label}
                    className="hover-lift border-border/50"
                    style={{ animation: `fade-in 0.6s ease-out ${i * 0.1}s both` }}
                  >
                    <CardContent className="p-6 flex flex-col items-center gap-2 text-center">
                      <div className="rounded-full bg-primary/10 p-3 animate-float" style={{ animationDelay: `${i * 0.3}s` }}>
                        <f.icon className={`h-6 w-6 ${f.color}`} />
                      </div>
                      <p className="font-medium text-sm">{f.label}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="bg-muted/30 py-20 border-y border-border/40">
        <div className="container">
          <div className="text-center mb-12 animate-fade-in">
            <div className="inline-flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-primary mb-3">
              <span className="h-px w-8 bg-primary" /> Process <span className="h-px w-8 bg-primary" />
            </div>
            <h2 className="text-3xl md:text-4xl font-bold">How it works</h2>
            <p className="text-muted-foreground mt-2">From doorstep to doorstep in four simple steps.</p>
          </div>
          <div className="grid md:grid-cols-4 gap-6">
            {[
              { n: 1, t: "Book", d: "Customer books a parcel from origin to destination hub." },
              { n: 2, t: "Receive at hub", d: "Origin hub staff receives & dispatches the parcel." },
              { n: 3, t: "Transit", d: "Parcel moves to destination hub." },
              { n: 4, t: "Notify & Deliver", d: "Receiver gets notified, pays (if needed), and collects." },
            ].map((s, i) => (
              <Card
                key={s.n}
                className="hover-lift border-border/50 relative overflow-hidden group"
                style={{ animation: `fade-in 0.5s ease-out ${i * 0.1}s both` }}
              >
                <div className="absolute top-0 right-0 text-7xl font-bold text-primary/5 leading-none p-2 group-hover:text-primary/10 transition-colors">
                  {s.n}
                </div>
                <CardContent className="p-6 relative">
                  <div className="h-10 w-10 rounded-full bg-gradient-hero text-primary-foreground flex items-center justify-center font-bold mb-3 shadow-md shadow-primary/30">
                    {s.n}
                  </div>
                  <h3 className="font-semibold mb-1">{s.t}</h3>
                  <p className="text-sm text-muted-foreground">{s.d}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section className="container py-20">
        <Card className="bg-gradient-hero border-0 overflow-hidden relative">
          <div className="absolute inset-0 opacity-20" style={{ backgroundImage: "radial-gradient(circle at 30% 50%, white 0%, transparent 50%)" }} />
          <CardContent className="p-10 md:p-14 relative flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="text-primary-foreground">
              <h2 className="text-2xl md:text-3xl font-bold">Ready to send your first parcel?</h2>
              <p className="opacity-90 mt-1">Sign up free. Pay only when you ship.</p>
            </div>
            <Link to={user ? "/app/send" : "/auth"}>
              <Button size="lg" variant="secondary" className="hover-scale shadow-xl">
                Get started <ArrowRight className="ml-1 h-4 w-4" />
              </Button>
            </Link>
          </CardContent>
        </Card>
      </section>

      <footer className="border-t py-8 text-center text-sm text-muted-foreground">
        <Clock className="inline h-4 w-4 mr-1" /> CourierBD &copy; 2026 — Built with care in Bangladesh
      </footer>
    </div>
  );
}
