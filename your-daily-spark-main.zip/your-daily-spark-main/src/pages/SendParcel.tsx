import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { toast } from "sonner";

interface Hub { id: string; name: string; city: string }

const schema = z.object({
  receiver_name: z.string().trim().min(2).max(80),
  receiver_phone: z.string().trim().min(6).max(20),
  receiver_address: z.string().trim().min(5).max(500),
  origin_hub_id: z.string().uuid(),
  destination_hub_id: z.string().uuid(),
  weight_kg: z.coerce.number().min(0.1).max(100),
  amount: z.coerce.number().min(0).max(100000),
  payment_by: z.enum(["sender", "receiver"]),
  notes: z.string().trim().max(500).optional(),
});

export default function SendParcel() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [hubs, setHubs] = useState<Hub[]>([]);
  const [origin, setOrigin] = useState("");
  const [destination, setDestination] = useState("");
  const [paymentBy, setPaymentBy] = useState<"sender" | "receiver">("sender");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    supabase.from("hubs").select("id,name,city").order("name").then(({ data }) => {
      if (data) setHubs(data);
    });
  }, []);

  const onSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const raw = {
      ...Object.fromEntries(fd),
      origin_hub_id: origin,
      destination_hub_id: destination,
      payment_by: paymentBy,
    };
    const parsed = schema.safeParse(raw);
    if (!parsed.success) {
      toast.error(parsed.error.issues[0].message);
      return;
    }
    if (parsed.data.origin_hub_id === parsed.data.destination_hub_id) {
      toast.error("Origin and destination hub must be different");
      return;
    }
    setBusy(true);
    const d = parsed.data;
    const { data, error } = await supabase
      .from("parcels")
      .insert({
        sender_id: user!.id,
        tracking_code: "",
        receiver_name: d.receiver_name,
        receiver_phone: d.receiver_phone,
        receiver_address: d.receiver_address,
        origin_hub_id: d.origin_hub_id,
        destination_hub_id: d.destination_hub_id,
        weight_kg: d.weight_kg,
        amount: d.amount,
        payment_by: d.payment_by,
        notes: d.notes,
      })
      .select("id, tracking_code")
      .single();
    setBusy(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success(`Parcel booked! Tracking: ${data.tracking_code}`);
    navigate(`/app/parcel/${data.id}`);
  };

  return (
    <Card className="max-w-2xl">
      <CardHeader>
        <CardTitle>Send a Parcel</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={onSubmit} className="space-y-4">
          <div className="grid sm:grid-cols-2 gap-3">
            <div className="space-y-1">
              <Label>Receiver name</Label>
              <Input name="receiver_name" required />
            </div>
            <div className="space-y-1">
              <Label>Receiver phone</Label>
              <Input name="receiver_phone" required />
            </div>
          </div>
          <div className="space-y-1">
            <Label>Receiver address</Label>
            <Textarea name="receiver_address" required rows={2} />
          </div>
          <div className="grid sm:grid-cols-2 gap-3">
            <div className="space-y-1">
              <Label>Origin hub</Label>
              <Select value={origin} onValueChange={setOrigin}>
                <SelectTrigger><SelectValue placeholder="Select origin" /></SelectTrigger>
                <SelectContent>
                  {hubs.map((h) => <SelectItem key={h.id} value={h.id}>{h.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <Label>Destination hub</Label>
              <Select value={destination} onValueChange={setDestination}>
                <SelectTrigger><SelectValue placeholder="Select destination" /></SelectTrigger>
                <SelectContent>
                  {hubs.map((h) => <SelectItem key={h.id} value={h.id}>{h.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="grid sm:grid-cols-2 gap-3">
            <div className="space-y-1">
              <Label>Weight (kg)</Label>
              <Input name="weight_kg" type="number" step="0.1" defaultValue="1" required />
            </div>
            <div className="space-y-1">
              <Label>Delivery charge (BDT)</Label>
              <Input name="amount" type="number" step="1" defaultValue="100" required />
            </div>
          </div>
          <div className="space-y-2">
            <Label>Payment will be made by</Label>
            <RadioGroup value={paymentBy} onValueChange={(v) => setPaymentBy(v as any)} className="grid sm:grid-cols-2 gap-3">
              <Label className="flex items-center gap-2 border rounded-md p-3 cursor-pointer hover:bg-accent">
                <RadioGroupItem value="sender" /> Sender (me) pays now
              </Label>
              <Label className="flex items-center gap-2 border rounded-md p-3 cursor-pointer hover:bg-accent">
                <RadioGroupItem value="receiver" /> Receiver pays on delivery
              </Label>
            </RadioGroup>
            <p className="text-xs text-muted-foreground">
              Parcel will not be released until payment is collected.
            </p>
          </div>
          <div className="space-y-1">
            <Label>Notes (optional)</Label>
            <Textarea name="notes" rows={2} />
          </div>
          <Button type="submit" disabled={busy} className="w-full">
            {busy ? "Booking..." : "Book parcel"}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
