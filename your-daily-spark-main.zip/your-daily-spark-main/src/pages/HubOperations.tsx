import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { Link } from "react-router-dom";

export default function HubOperations() {
  const { user, hubId, primaryRole } = useAuth();
  const [parcels, setParcels] = useState<any[]>([]);
  const [hubs, setHubs] = useState<Record<string, { name: string; city: string }>>({});
  const [myHub, setMyHub] = useState<string | null>(hubId);

  useEffect(() => { setMyHub(hubId); }, [hubId]);

  const load = async () => {
    let q = supabase.from("parcels").select("*").order("created_at", { ascending: false }).limit(100);
    if (primaryRole === "hub_staff" && myHub) {
      q = q.or(`origin_hub_id.eq.${myHub},destination_hub_id.eq.${myHub},current_hub_id.eq.${myHub}`);
    }
    const { data } = await q;
    setParcels(data || []);
    const { data: hs } = await supabase.from("hubs").select("id,name,city");
    if (hs) setHubs(Object.fromEntries(hs.map((h) => [h.id, { name: h.name, city: h.city }])));
  };

  useEffect(() => { load(); }, [myHub, primaryRole]);

  const addEvent = async (parcel_id: string, event_type: string, message: string, hub_id?: string) => {
    await supabase.from("parcel_events").insert({
      parcel_id, event_type, message, hub_id: hub_id ?? myHub, actor_id: user!.id,
    });
  };

  const notify = async (user_id: string, parcel_id: string, title: string, message: string) => {
    await supabase.from("notifications").insert({ user_id, parcel_id, title, message });
  };

  const receiveAtOrigin = async (p: any) => {
    const { error } = await supabase.from("parcels").update({ status: "at_origin_hub", current_hub_id: p.origin_hub_id }).eq("id", p.id);
    if (error) return toast.error(error.message);
    await addEvent(p.id, "received_at_origin", "Parcel received at origin hub", p.origin_hub_id);
    toast.success("Marked as received at origin");
    load();
  };

  const dispatch = async (p: any) => {
    const { error } = await supabase.from("parcels").update({ status: "in_transit" }).eq("id", p.id);
    if (error) return toast.error(error.message);
    await addEvent(p.id, "dispatched", `Dispatched to ${hubs[p.destination_hub_id]?.name}`);
    toast.success("Dispatched to destination hub");
    load();
  };

  const receiveAtDest = async (p: any) => {
    const { error } = await supabase.from("parcels").update({ status: "at_destination_hub", current_hub_id: p.destination_hub_id }).eq("id", p.id);
    if (error) return toast.error(error.message);
    await addEvent(p.id, "arrived_at_destination", "Arrived at destination hub", p.destination_hub_id);
    await notify(
      p.sender_id,
      p.id,
      "Parcel arrived",
      `Your parcel ${p.tracking_code} arrived at ${hubs[p.destination_hub_id]?.name}. Please come collect it. Payment ${p.payment_status === "paid" ? "already received" : `of ৳${p.amount} pending (${p.payment_by} pays)`}.`
    );
    toast.success("Marked as arrived. Customer notified.");
    load();
  };

  const collectPayment = async (p: any) => {
    const { error } = await supabase.from("parcels").update({ payment_status: "paid" }).eq("id", p.id);
    if (error) return toast.error(error.message);
    await addEvent(p.id, "payment_collected", `৳${p.amount} collected from ${p.payment_by}`);
    toast.success("Payment marked as collected");
    load();
  };

  const deliver = async (p: any) => {
    if (p.payment_status !== "paid") {
      toast.error("Cannot deliver: payment is not collected yet.");
      return;
    }
    const { error } = await supabase.from("parcels").update({ status: "delivered" }).eq("id", p.id);
    if (error) return toast.error(error.message);
    await addEvent(p.id, "delivered", "Parcel delivered to receiver");
    await notify(p.sender_id, p.id, "Parcel delivered", `Your parcel ${p.tracking_code} has been delivered.`);
    toast.success("Delivered!");
    load();
  };

  const renderActions = (p: any) => {
    const isOrigin = p.origin_hub_id === myHub;
    const isDest = p.destination_hub_id === myHub;
    return (
      <div className="flex flex-wrap gap-2">
        {p.status === "pending_pickup" && isOrigin && (
          <Button size="sm" onClick={() => receiveAtOrigin(p)}>Receive at hub</Button>
        )}
        {p.status === "at_origin_hub" && isOrigin && (
          <Button size="sm" onClick={() => dispatch(p)}>Dispatch</Button>
        )}
        {p.status === "in_transit" && isDest && (
          <Button size="sm" onClick={() => receiveAtDest(p)}>Receive at destination</Button>
        )}
        {p.status === "at_destination_hub" && isDest && p.payment_status === "unpaid" && (
          <Button size="sm" variant="secondary" onClick={() => collectPayment(p)}>
            Collect ৳{p.amount} ({p.payment_by})
          </Button>
        )}
        {p.status === "at_destination_hub" && isDest && p.payment_status === "paid" && (
          <Button size="sm" onClick={() => deliver(p)}>Mark delivered</Button>
        )}
        <Link to={`/app/parcel/${p.id}`}><Button size="sm" variant="outline">View</Button></Link>
      </div>
    );
  };

  return (
    <Card className="border-border/50 animate-fade-in">
      <CardHeader>
        <CardTitle>
          Hub Operations {myHub && hubs[myHub] ? <span className="text-primary">— {hubs[myHub].name}</span> : ""}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {primaryRole === "hub_staff" && !myHub && (
          <p className="text-destructive text-sm">You are not assigned to a hub yet. Please contact admin.</p>
        )}
        {parcels.length === 0 ? (
          <div className="py-10 text-center text-muted-foreground text-sm">No parcels for this hub.</div>
        ) : (
          parcels.map((p, i) => (
            <div
              key={p.id}
              className="border border-border/50 rounded-lg p-3 space-y-2 hover:border-primary/30 hover:shadow-md transition-all"
              style={{ animation: `slide-in-right 0.4s ease-out ${i * 0.04}s both` }}
            >
              <div className="flex justify-between items-start flex-wrap gap-2">
                <div>
                  <div className="font-semibold">{p.tracking_code}</div>
                  <div className="text-xs text-muted-foreground">
                    {hubs[p.origin_hub_id]?.city} → {hubs[p.destination_hub_id]?.city} • {p.receiver_name} ({p.receiver_phone})
                  </div>
                </div>
                <div className="flex gap-1">
                  <Badge variant="outline" className="capitalize">{p.status.replace(/_/g, " ")}</Badge>
                  <Badge variant={p.payment_status === "paid" ? "default" : "destructive"}>{p.payment_status}</Badge>
                </div>
              </div>
              {renderActions(p)}
            </div>
          ))
        )}
      </CardContent>
    </Card>
  );
}
