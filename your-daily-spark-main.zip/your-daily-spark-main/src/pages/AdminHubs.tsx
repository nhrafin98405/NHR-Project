import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";

export default function AdminHubs() {
  const [hubs, setHubs] = useState<any[]>([]);
  const load = () => supabase.from("hubs").select("*").order("name").then(({ data }) => setHubs(data || []));
  useEffect(() => { load(); }, []);

  const onSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const name = String(fd.get("name") || "").trim();
    const city = String(fd.get("city") || "").trim();
    const address = String(fd.get("address") || "").trim();
    if (!name || !city) return toast.error("Name and city required");
    const { error } = await supabase.from("hubs").insert({ name, city, address });
    if (error) toast.error(error.message);
    else { toast.success("Hub added"); (e.target as HTMLFormElement).reset(); load(); }
  };

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader><CardTitle>Add new hub</CardTitle></CardHeader>
        <CardContent>
          <form onSubmit={onSubmit} className="grid sm:grid-cols-4 gap-2">
            <div className="space-y-1"><Label>Name</Label><Input name="name" required /></div>
            <div className="space-y-1"><Label>City</Label><Input name="city" required /></div>
            <div className="space-y-1 sm:col-span-1"><Label>Address</Label><Input name="address" /></div>
            <Button type="submit" className="self-end">Add</Button>
          </form>
        </CardContent>
      </Card>
      <Card>
        <CardHeader><CardTitle>All hubs</CardTitle></CardHeader>
        <CardContent className="space-y-2">
          {hubs.map((h) => (
            <div key={h.id} className="border rounded-md p-3">
              <div className="font-medium">{h.name}</div>
              <div className="text-xs text-muted-foreground">{h.city} • {h.address || "—"}</div>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}
