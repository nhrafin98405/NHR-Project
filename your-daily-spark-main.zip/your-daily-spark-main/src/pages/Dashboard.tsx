import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Package, CheckCircle2, Truck, Clock } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";

export default function Dashboard() {
  const { user, primaryRole, hubId } = useAuth();
  const [stats, setStats] = useState({ total: 0, transit: 0, delivered: 0, pending: 0 });

  useEffect(() => {
    const load = async () => {
      let q = supabase.from("parcels").select("status", { count: "exact" });
      if (primaryRole === "customer") q = q.eq("sender_id", user!.id);
      const { data } = await q;
      if (!data) return;
      setStats({
        total: data.length,
        transit: data.filter((p) => ["in_transit", "at_destination_hub", "out_for_delivery"].includes(p.status)).length,
        delivered: data.filter((p) => p.status === "delivered").length,
        pending: data.filter((p) => ["pending_pickup", "at_origin_hub"].includes(p.status)).length,
      });
    };
    if (user) load();
  }, [user, primaryRole, hubId]);

  const cards = [
    { label: "Total parcels", value: stats.total, icon: Package, color: "text-primary" },
    { label: "Pending", value: stats.pending, icon: Clock, color: "text-orange-500" },
    { label: "In transit", value: stats.transit, icon: Truck, color: "text-blue-500" },
    { label: "Delivered", value: stats.delivered, icon: CheckCircle2, color: "text-green-600" },
  ];

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Welcome back!</h1>
        <p className="text-muted-foreground capitalize">Logged in as {primaryRole?.replace("_", " ")}</p>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {cards.map((c, i) => (
          <Card
            key={c.label}
            className="hover-lift border-border/50 relative overflow-hidden group"
            style={{ animation: `scale-in 0.4s ease-out ${i * 0.08}s both` }}
          >
            <div className="absolute -right-4 -top-4 h-20 w-20 rounded-full bg-primary/5 group-hover:bg-primary/10 transition-colors" />
            <CardContent className="p-5 relative">
              <div className={`inline-flex p-2 rounded-lg bg-primary/10 mb-2 ${c.color}`}>
                <c.icon className="h-5 w-5" />
              </div>
              <div className="text-3xl font-bold tracking-tight">{c.value}</div>
              <div className="text-xs text-muted-foreground mt-0.5">{c.label}</div>
            </CardContent>
          </Card>
        ))}
      </div>
      {primaryRole === "customer" && (
        <Card className="border-border/50 animate-fade-in" style={{ animationDelay: "0.3s" }}>
          <CardHeader>
            <CardTitle>Quick actions</CardTitle>
          </CardHeader>
          <CardContent className="flex flex-wrap gap-3">
            <Link to="/app/send"><Button className="hover-scale bg-gradient-hero shadow-md shadow-primary/20">Send new parcel</Button></Link>
            <Link to="/app/my-parcels"><Button variant="outline" className="hover-scale">View my parcels</Button></Link>
          </CardContent>
        </Card>
      )}
      {primaryRole === "hub_staff" && (
        <Card className="border-border/50 animate-fade-in">
          <CardHeader><CardTitle>Hub Operations</CardTitle></CardHeader>
          <CardContent>
            <Link to="/app/hub"><Button className="hover-scale bg-gradient-hero">Go to hub queue</Button></Link>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
