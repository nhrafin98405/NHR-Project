import { Link, useLocation } from "react-router-dom";
import { useEffect } from "react";
import { Button } from "@/components/ui/button";
import { PackageX, ArrowLeft } from "lucide-react";

const NotFound = () => {
  const location = useLocation();

  useEffect(() => {
    console.error("404 Error: User attempted to access non-existent route:", location.pathname);
  }, [location.pathname]);

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-mesh p-4">
      <div className="text-center animate-scale-in">
        <div className="mx-auto mb-6 flex h-20 w-20 items-center justify-center rounded-2xl bg-gradient-hero text-primary-foreground shadow-xl shadow-primary/30 animate-float">
          <PackageX className="h-10 w-10" />
        </div>
        <h1 className="mb-2 text-7xl font-bold text-gradient">404</h1>
        <p className="mb-1 text-xl font-semibold">Parcel not found</p>
        <p className="mb-6 text-sm text-muted-foreground">The page you're looking for doesn't exist.</p>
        <Link to="/">
          <Button className="bg-gradient-hero hover-scale shadow-lg shadow-primary/30">
            <ArrowLeft className="mr-1 h-4 w-4" /> Back to Home
          </Button>
        </Link>
      </div>
    </div>
  );
};

export default NotFound;
