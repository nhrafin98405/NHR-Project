import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";

export default function AdminUsers() {
  const [profiles, setProfiles] = useState<any[]>([]);
  const [roles, setRoles] = useState<Record<string, { role: string; hub_id: string | null }[]>>({});
  const [hubs, setHubs] = useState<any[]>([]);

  const load = async () => {
    const { data: p } = await supabase.from("profiles").select("*").order("created_at", { ascending: false });
    setProfiles(p || []);
    const { data: r } = await supabase.from("user_roles").select("user_id,role,hub_id");
    const grouped: Record<string, any[]> = {};
    (r || []).forEach((row) => {
      grouped[row.user_id] = grouped[row.user_id] || [];
      grouped[row.user_id].push({ role: row.role, hub_id: row.hub_id });
    });
    setRoles(grouped);
    const { data: h } = await supabase.from("hubs").select("id,name");
    setHubs(h || []);
  };
  useEffect(() => { load(); }, []);

  const setRole = async (uid: string, newRole: string, hubId: string | null) => {
    // remove existing role of same kind, then insert new
    await supabase.from("user_roles").delete().eq("user_id", uid).neq("role", "customer");
    if (newRole !== "customer") {
      const { error } = await supabase.from("user_roles").insert({
        user_id: uid, role: newRole as any, hub_id: newRole === "hub_staff" ? hubId : null,
      });
      if (error) return toast.error(error.message);
    }
    toast.success("Role updated");
    load();
  };

  return (
    <Card>
      <CardHeader><CardTitle>Manage Users</CardTitle></CardHeader>
      <CardContent className="space-y-3">
        {profiles.map((p) => {
          const userRoles = roles[p.id] || [];
          const elevated = userRoles.find((r) => r.role !== "customer");
          return (
            <div key={p.id} className="border rounded-md p-3 flex flex-wrap gap-3 items-center">
              <div className="flex-1 min-w-[200px]">
                <div className="font-medium">{p.full_name || p.email}</div>
                <div className="text-xs text-muted-foreground">{p.email} • {p.phone || "—"}</div>
                <div className="flex gap-1 mt-1">
                  {userRoles.map((r) => <Badge key={r.role} variant="secondary">{r.role}</Badge>)}
                </div>
              </div>
              <RoleSelector
                current={elevated?.role || "customer"}
                hubId={elevated?.hub_id || null}
                hubs={hubs}
                onApply={(role, hub) => setRole(p.id, role, hub)}
              />
            </div>
          );
        })}
      </CardContent>
    </Card>
  );
}

function RoleSelector({ current, hubId, hubs, onApply }: any) {
  const [role, setRole] = useState(current);
  const [hub, setHub] = useState(hubId || "");
  return (
    <div className="flex gap-2 items-center flex-wrap">
      <Select value={role} onValueChange={setRole}>
        <SelectTrigger className="w-36"><SelectValue /></SelectTrigger>
        <SelectContent>
          <SelectItem value="customer">Customer</SelectItem>
          <SelectItem value="hub_staff">Hub staff</SelectItem>
          <SelectItem value="admin">Admin</SelectItem>
        </SelectContent>
      </Select>
      {role === "hub_staff" && (
        <Select value={hub} onValueChange={setHub}>
          <SelectTrigger className="w-44"><SelectValue placeholder="Pick hub" /></SelectTrigger>
          <SelectContent>
            {hubs.map((h: any) => <SelectItem key={h.id} value={h.id}>{h.name}</SelectItem>)}
          </SelectContent>
        </Select>
      )}
      <Button size="sm" onClick={() => onApply(role, hub || null)}>Apply</Button>
    </div>
  );
}
