import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Package, MapPin, Phone, User, Wallet } from "lucide-react";

export default function ParcelDetail() {
  const { id } = useParams();
  const [parcel, setParcel] = useState<any>(null);
  const [events, setEvents] = useState<any[]>([]);
  const [hubs, setHubs] = useState<Record<string, string>>({});

  useEffect(() => {
    if (!id) return;
    const load = async () => {
      const { data: p } = await supabase.from("parcels").select("*").eq("id", id).maybeSingle();
      setParcel(p);
      const { data: ev } = await supabase
        .from("parcel_events")
        .select("*")
        .eq("parcel_id", id)
        .order("created_at", { ascending: true });
      setEvents(ev || []);
      const { data: hs } = await supabase.from("hubs").select("id,name");
      if (hs) setHubs(Object.fromEntries(hs.map((h) => [h.id, h.name])));
    };
    load();
    const ch = supabase
      .channel(`parcel-${id}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "parcel_events", filter: `parcel_id=eq.${id}` }, load)
      .on("postgres_changes", { event: "UPDATE", schema: "public", table: "parcels", filter: `id=eq.${id}` }, load)
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [id]);

  if (!parcel) return <p className="text-muted-foreground">Loading...</p>;

  return (
    <div className="space-y-4 animate-fade-in">
      <Card className="border-border/50 overflow-hidden">
        <div className="h-1 bg-gradient-hero" />
        <CardHeader>
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div>
              <CardTitle className="flex items-center gap-2 text-xl">
                <div className="h-9 w-9 rounded-lg bg-primary/10 flex items-center justify-center">
                  <Package className="h-5 w-5 text-primary" />
                </div>
                {parcel.tracking_code}
              </CardTitle>
            </div>
            <div className="flex gap-2">
              <Badge className="capitalize">{parcel.status.replace(/_/g, " ")}</Badge>
              <Badge variant={parcel.payment_status === "paid" ? "default" : "destructive"}>
                {parcel.payment_status}
              </Badge>
            </div>
          </div>
        </CardHeader>
        <CardContent className="grid sm:grid-cols-2 gap-4 text-sm">
          <div className="flex items-center gap-2 p-2 rounded-md bg-muted/30"><User className="h-4 w-4 text-muted-foreground" /> {parcel.receiver_name}</div>
          <div className="flex items-center gap-2 p-2 rounded-md bg-muted/30"><Phone className="h-4 w-4 text-muted-foreground" /> {parcel.receiver_phone}</div>
          <div className="sm:col-span-2 flex items-start gap-2 p-2 rounded-md bg-muted/30"><MapPin className="h-4 w-4 text-muted-foreground mt-0.5" /> {parcel.receiver_address}</div>
          <div><strong className="text-muted-foreground">From:</strong> {hubs[parcel.origin_hub_id]}</div>
          <div><strong className="text-muted-foreground">To:</strong> {hubs[parcel.destination_hub_id]}</div>
          <div><strong className="text-muted-foreground">Currently at:</strong> {hubs[parcel.current_hub_id] || "—"}</div>
          <div className="flex items-center gap-1.5 font-medium"><Wallet className="h-4 w-4 text-primary" /> ৳{parcel.amount} • {parcel.payment_by} pays</div>
        </CardContent>
      </Card>

      <Card className="border-border/50">
        <CardHeader><CardTitle>Tracking Timeline</CardTitle></CardHeader>
        <CardContent>
          {events.length === 0 ? (
            <p className="text-sm text-muted-foreground">No events yet.</p>
          ) : (
            <ol className="relative border-l-2 border-primary/20 ml-2 space-y-5 pl-4">
              {events.map((e, i) => (
                <li
                  key={e.id}
                  className="relative"
                  style={{ animation: `slide-in-right 0.4s ease-out ${i * 0.08}s both` }}
                >
                  <div className="absolute -left-[1.4rem] mt-1 w-3 h-3 bg-primary rounded-full ring-4 ring-primary/20" />
                  <time className="text-xs text-muted-foreground">{new Date(e.created_at).toLocaleString()}</time>
                  <h3 className="text-sm font-semibold capitalize mt-0.5">{e.event_type.replace(/_/g, " ")}</h3>
                  <p className="text-sm text-muted-foreground">{e.message} {e.hub_id && hubs[e.hub_id] ? `@ ${hubs[e.hub_id]}` : ""}</p>
                </li>
              ))}
            </ol>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
