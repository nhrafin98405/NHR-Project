import { Link, NavLink, Outlet, useNavigate } from "react-router-dom";
import { Package, LogOut, Bell, Home, Send, Building2, Users, Inbox } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { cn } from "@/lib/utils";

export default function AppLayout() {
  const { user, primaryRole, signOut } = useAuth();
  const navigate = useNavigate();
  const [unread, setUnread] = useState(0);

  useEffect(() => {
    if (!user) return;
    const load = async () => {
      const { count } = await supabase
        .from("notifications")
        .select("*", { count: "exact", head: true })
        .eq("user_id", user.id)
        .eq("read", false);
      setUnread(count ?? 0);
    };
    load();
    const channel = supabase
      .channel("notif-count")
      .on("postgres_changes", { event: "*", schema: "public", table: "notifications" }, load)
      .subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, [user]);

  const links = [
    { to: "/app", label: "Dashboard", icon: Home, roles: ["customer", "hub_staff", "admin"] },
    { to: "/app/send", label: "Send Parcel", icon: Send, roles: ["customer", "admin"] },
    { to: "/app/my-parcels", label: "My Parcels", icon: Package, roles: ["customer", "admin"] },
    { to: "/app/hub", label: "Hub Operations", icon: Inbox, roles: ["hub_staff", "admin"] },
    { to: "/app/hubs", label: "Hubs", icon: Building2, roles: ["admin"] },
    { to: "/app/users", label: "Users", icon: Users, roles: ["admin"] },
  ].filter((l) => primaryRole && l.roles.includes(primaryRole));

  return (
    <div className="min-h-screen bg-muted/30">
      <header className="sticky top-0 z-40 border-b bg-background/80 backdrop-blur">
        <div className="container flex h-16 items-center justify-between gap-4">
          <Link to="/app" className="flex items-center gap-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary text-primary-foreground">
              <Package className="h-5 w-5" />
            </div>
            <span className="font-bold text-lg">CourierBD</span>
          </Link>
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="icon" onClick={() => navigate("/app/notifications")} className="relative">
              <Bell className="h-5 w-5" />
              {unread > 0 && (
                <span className="absolute -top-0.5 -right-0.5 flex h-5 min-w-5 items-center justify-center rounded-full bg-destructive px-1 text-[10px] font-bold text-destructive-foreground">
                  {unread}
                </span>
              )}
            </Button>
            <Button variant="ghost" size="sm" onClick={async () => { await signOut(); navigate("/"); }}>
              <LogOut className="h-4 w-4 mr-1" /> Logout
            </Button>
          </div>
        </div>
      </header>
      <div className="container grid md:grid-cols-[220px_1fr] gap-6 py-6">
        <aside className="hidden md:block">
          <nav className="flex flex-col gap-1 sticky top-20">
            {links.map((l) => (
              <NavLink
                key={l.to}
                to={l.to}
                end={l.to === "/app"}
                className={({ isActive }) =>
                  cn(
                    "flex items-center gap-2 rounded-md px-3 py-2 text-sm font-medium transition-colors",
                    isActive ? "bg-primary text-primary-foreground" : "hover:bg-accent"
                  )
                }
              >
                <l.icon className="h-4 w-4" /> {l.label}
              </NavLink>
            ))}
          </nav>
        </aside>
        <main className="min-w-0">
          <div className="md:hidden mb-4 flex flex-wrap gap-2">
            {links.map((l) => (
              <NavLink
                key={l.to}
                to={l.to}
                end={l.to === "/app"}
                className={({ isActive }) =>
                  cn(
                    "flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-medium border",
                    isActive ? "bg-primary text-primary-foreground border-primary" : "bg-background"
                  )
                }
              >
                <l.icon className="h-3.5 w-3.5" /> {l.label}
              </NavLink>
            ))}
          </div>
          <Outlet />
        </main>
      </div>
    </div>
  );
}
