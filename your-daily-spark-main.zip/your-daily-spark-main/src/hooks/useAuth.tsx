import { createContext, useContext, useEffect, useState, ReactNode } from "react";
import { supabase } from "@/integrations/supabase/client";
import type { Session, User } from "@supabase/supabase-js";

export type AppRole = "customer" | "hub_staff" | "admin";

interface AuthCtx {
  user: User | null;
  session: Session | null;
  loading: boolean;
  roles: AppRole[];
  hubId: string | null;
  primaryRole: AppRole | null;
  refreshRoles: () => Promise<void>;
  signOut: () => Promise<void>;
}

const Ctx = createContext<AuthCtx | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const [roles, setRoles] = useState<AppRole[]>([]);
  const [hubId, setHubId] = useState<string | null>(null);

  const loadRoles = async (uid: string) => {
    const { data } = await supabase.from("user_roles").select("role,hub_id").eq("user_id", uid);
    if (data) {
      setRoles(data.map((r) => r.role as AppRole));
      const staff = data.find((r) => r.role === "hub_staff");
      setHubId(staff?.hub_id ?? null);
    }
  };

  useEffect(() => {
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => {
      setSession(s);
      setUser(s?.user ?? null);
      if (s?.user) setTimeout(() => loadRoles(s.user.id), 0);
      else {
        setRoles([]);
        setHubId(null);
      }
    });
    supabase.auth.getSession().then(({ data: { session: s } }) => {
      setSession(s);
      setUser(s?.user ?? null);
      if (s?.user) loadRoles(s.user.id).finally(() => setLoading(false));
      else setLoading(false);
    });
    return () => sub.subscription.unsubscribe();
  }, []);

  const primaryRole: AppRole | null = roles.includes("admin")
    ? "admin"
    : roles.includes("hub_staff")
    ? "hub_staff"
    : roles.includes("customer")
    ? "customer"
    : null;

  return (
    <Ctx.Provider
      value={{
        user,
        session,
        loading,
        roles,
        hubId,
        primaryRole,
        refreshRoles: async () => user && loadRoles(user.id),
        signOut: async () => {
          await supabase.auth.signOut();
        },
      }}
    >
      {children}
    </Ctx.Provider>
  );
}

export function useAuth() {
  const c = useContext(Ctx);
  if (!c) throw new Error("useAuth must be used within AuthProvider");
  return c;
}
