
-- ============ ENUMS ============
CREATE TYPE public.app_role AS ENUM ('customer', 'hub_staff', 'admin');
CREATE TYPE public.parcel_status AS ENUM (
  'pending_pickup', 'at_origin_hub', 'in_transit',
  'at_destination_hub', 'out_for_delivery', 'delivered', 'cancelled'
);
CREATE TYPE public.payment_by AS ENUM ('sender', 'receiver');
CREATE TYPE public.payment_status AS ENUM ('unpaid', 'paid');

-- ============ PROFILES ============
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name TEXT,
  phone TEXT,
  email TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- ============ HUBS ============
CREATE TABLE public.hubs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  city TEXT NOT NULL,
  address TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.hubs ENABLE ROW LEVEL SECURITY;

-- ============ USER_ROLES ============
CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role public.app_role NOT NULL,
  hub_id UUID REFERENCES public.hubs(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, role)
);
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

-- ============ has_role FUNCTION (security definer to avoid RLS recursion) ============
CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role public.app_role)
RETURNS BOOLEAN
LANGUAGE SQL STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id AND role = _role
  );
$$;

CREATE OR REPLACE FUNCTION public.staff_hub_id(_user_id UUID)
RETURNS UUID
LANGUAGE SQL STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT hub_id FROM public.user_roles
  WHERE user_id = _user_id AND role = 'hub_staff'
  LIMIT 1;
$$;

-- ============ PARCELS ============
CREATE TABLE public.parcels (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tracking_code TEXT NOT NULL UNIQUE,
  sender_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  receiver_name TEXT NOT NULL,
  receiver_phone TEXT NOT NULL,
  receiver_address TEXT NOT NULL,
  origin_hub_id UUID NOT NULL REFERENCES public.hubs(id),
  destination_hub_id UUID NOT NULL REFERENCES public.hubs(id),
  current_hub_id UUID REFERENCES public.hubs(id),
  weight_kg NUMERIC(8,2) NOT NULL DEFAULT 1,
  amount NUMERIC(10,2) NOT NULL DEFAULT 0,
  payment_by public.payment_by NOT NULL DEFAULT 'sender',
  payment_status public.payment_status NOT NULL DEFAULT 'unpaid',
  status public.parcel_status NOT NULL DEFAULT 'pending_pickup',
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.parcels ENABLE ROW LEVEL SECURITY;

-- ============ PARCEL EVENTS ============
CREATE TABLE public.parcel_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  parcel_id UUID NOT NULL REFERENCES public.parcels(id) ON DELETE CASCADE,
  event_type TEXT NOT NULL,
  hub_id UUID REFERENCES public.hubs(id),
  actor_id UUID REFERENCES auth.users(id),
  message TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.parcel_events ENABLE ROW LEVEL SECURITY;

-- ============ NOTIFICATIONS ============
CREATE TABLE public.notifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  parcel_id UUID REFERENCES public.parcels(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  read BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

-- ============ updated_at TRIGGER ============
CREATE OR REPLACE FUNCTION public.tg_set_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$;
CREATE TRIGGER set_updated_at_profiles BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.tg_set_updated_at();
CREATE TRIGGER set_updated_at_parcels BEFORE UPDATE ON public.parcels
  FOR EACH ROW EXECUTE FUNCTION public.tg_set_updated_at();

-- ============ NEW USER -> profile + customer role ============
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name, email, phone)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data ->> 'full_name', NEW.email),
    NEW.email,
    NEW.raw_user_meta_data ->> 'phone'
  );
  INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'customer');
  RETURN NEW;
END;
$$;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- ============ PARCEL CREATE: tracking code + initial event + notification ============
CREATE OR REPLACE FUNCTION public.handle_new_parcel()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NEW.tracking_code IS NULL OR NEW.tracking_code = '' THEN
    NEW.tracking_code := 'CR' || to_char(now(),'YYMMDD') || upper(substr(replace(gen_random_uuid()::text,'-',''),1,6));
  END IF;
  IF NEW.current_hub_id IS NULL THEN
    NEW.current_hub_id := NEW.origin_hub_id;
  END IF;
  RETURN NEW;
END;
$$;
CREATE TRIGGER before_parcel_insert
  BEFORE INSERT ON public.parcels
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_parcel();

CREATE OR REPLACE FUNCTION public.after_new_parcel()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.parcel_events (parcel_id, event_type, hub_id, actor_id, message)
  VALUES (NEW.id, 'created', NEW.origin_hub_id, NEW.sender_id,
          'Parcel booked. Tracking: ' || NEW.tracking_code);
  INSERT INTO public.notifications (user_id, parcel_id, title, message)
  VALUES (NEW.sender_id, NEW.id, 'Parcel booked',
          'Your parcel ' || NEW.tracking_code || ' has been booked successfully.');
  RETURN NEW;
END;
$$;
CREATE TRIGGER after_parcel_insert
  AFTER INSERT ON public.parcels
  FOR EACH ROW EXECUTE FUNCTION public.after_new_parcel();

-- ============ RLS POLICIES ============
-- profiles
CREATE POLICY "profiles self read" ON public.profiles
  FOR SELECT TO authenticated
  USING (auth.uid() = id OR public.has_role(auth.uid(),'admin') OR public.has_role(auth.uid(),'hub_staff'));
CREATE POLICY "profiles self update" ON public.profiles
  FOR UPDATE TO authenticated USING (auth.uid() = id);
CREATE POLICY "profiles admin update" ON public.profiles
  FOR UPDATE TO authenticated USING (public.has_role(auth.uid(),'admin'));

-- user_roles
CREATE POLICY "roles self read" ON public.user_roles
  FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.has_role(auth.uid(),'admin'));
CREATE POLICY "roles admin write" ON public.user_roles
  FOR ALL TO authenticated
  USING (public.has_role(auth.uid(),'admin'))
  WITH CHECK (public.has_role(auth.uid(),'admin'));

-- hubs
CREATE POLICY "hubs read all auth" ON public.hubs
  FOR SELECT TO authenticated USING (true);
CREATE POLICY "hubs admin write" ON public.hubs
  FOR ALL TO authenticated
  USING (public.has_role(auth.uid(),'admin'))
  WITH CHECK (public.has_role(auth.uid(),'admin'));

-- parcels
CREATE POLICY "parcels customer insert" ON public.parcels
  FOR INSERT TO authenticated WITH CHECK (sender_id = auth.uid());
CREATE POLICY "parcels read" ON public.parcels
  FOR SELECT TO authenticated USING (
    sender_id = auth.uid()
    OR public.has_role(auth.uid(),'admin')
    OR (public.has_role(auth.uid(),'hub_staff') AND
        public.staff_hub_id(auth.uid()) IN (origin_hub_id, destination_hub_id, current_hub_id))
  );
CREATE POLICY "parcels staff update" ON public.parcels
  FOR UPDATE TO authenticated USING (
    public.has_role(auth.uid(),'admin')
    OR (public.has_role(auth.uid(),'hub_staff') AND
        public.staff_hub_id(auth.uid()) IN (origin_hub_id, destination_hub_id, current_hub_id))
  );

-- parcel_events
CREATE POLICY "events read" ON public.parcel_events
  FOR SELECT TO authenticated USING (
    EXISTS (SELECT 1 FROM public.parcels p WHERE p.id = parcel_id AND (
      p.sender_id = auth.uid()
      OR public.has_role(auth.uid(),'admin')
      OR (public.has_role(auth.uid(),'hub_staff') AND
          public.staff_hub_id(auth.uid()) IN (p.origin_hub_id, p.destination_hub_id, p.current_hub_id))
    ))
  );
CREATE POLICY "events staff insert" ON public.parcel_events
  FOR INSERT TO authenticated WITH CHECK (
    public.has_role(auth.uid(),'admin') OR public.has_role(auth.uid(),'hub_staff') OR actor_id = auth.uid()
  );

-- notifications
CREATE POLICY "notif self read" ON public.notifications
  FOR SELECT TO authenticated USING (user_id = auth.uid());
CREATE POLICY "notif self update" ON public.notifications
  FOR UPDATE TO authenticated USING (user_id = auth.uid());
CREATE POLICY "notif insert any auth" ON public.notifications
  FOR INSERT TO authenticated WITH CHECK (true);

-- Seed hubs
INSERT INTO public.hubs (name, city, address) VALUES
  ('Dhaka Central Hub', 'Dhaka', 'Motijheel, Dhaka'),
  ('Mymensingh Hub', 'Mymensingh', 'Town Hall Road, Mymensingh'),
  ('Chittagong Hub', 'Chittagong', 'Agrabad, Chittagong');
